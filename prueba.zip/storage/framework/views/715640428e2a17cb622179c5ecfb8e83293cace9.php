

<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>LISTADO DE PERSONAS</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<a href="personas/create" class="btn btn-success mb-4">CREAR</a>
<a href="/export-personas" class="btn btn-primary mb-4">Descargar Excel</a>
<a href="/imprimir" class="btn btn-info mb-4">Descargar PDF</a>
    <table id="personas" class="table table-light table-striped">
    <thead>
    <tr>
    <th>ID</th>
    <th>Nombre</th>
    <th>Apellidos</th>
    <th>Acciones</th>
    </tr>
    </thead>
    <tbody>
    <?php $__currentLoopData = $personas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $persona): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
    <td> <?php echo e($persona->id); ?> </td>
    <td> <?php echo e($persona->nombre); ?> </td>
    <td> <?php echo e($persona->apellido_paterno . ' ' . $persona->apellido_materno); ?> </td>
    <td> 
    <form action="<?php echo e(route('personas.destroy', $persona->id)); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <?php echo method_field('DELETE'); ?>
    <a href="/personas/<?php echo e($persona->id); ?>/edit" class="btn btn-primary">Editar</a>
    <a href="/personas/<?php echo e($persona->id); ?>" class="btn btn-info">Ver</a>
    <button type="submit" class="btn btn-danger">Eliminar</button>
    </form>
    </td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
    </table>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/admin_custom.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.22/css/dataTables.bootstrap5.min.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
    <script src="https://cdn.datatables.net/1.10.24/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.24/js/dataTables.bootstrap5.min.js"></script>

    <script>
    $(document).ready(function() {
        $('#personas').DataTable({
            "lengthMenu": [[5,10,50, -1], [5, 10, 50, "All"]]
        });
    });
    </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\HUMAN VALUE\prueba\resources\views/persona/index.blade.php ENDPATH**/ ?>