<style>
#emp{
    font-family: Arial, Helvetica, sans-serif;
    border-collapse: collapse;
    width: 100;
}

#emp td, #emp th{
    border: 1px solid #ddd;
    padding: 8px;
}
#emp th{
    padding-top: 12px;
    padding-bottom: 12px;
    text-align: left;
    background-color: #4CAF50;
    color: #fff;
}
</style>
<table id="emp" class="table table-light table-striped">
    <thead>
    <tr>
    <th>ID</th>
    <th>Nombre</th>
    <th>Apellidos</th>
    <th>CI</th>
    <th>Direccion</th>
    </tr>
    </thead>
    <tbody>
    <?php $__currentLoopData = $personas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $persona): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
    <td> <?php echo e($persona->id); ?> </td>
    <td> <?php echo e($persona->nombre); ?> </td>
    <td> <?php echo e($persona->apellido_paterno . ' ' . $persona->apellido_materno); ?> </td>
    <td> <?php echo e($persona->ci); ?> </td>
    <td> <?php echo e($persona->direccion); ?> </td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
    </table><?php /**PATH C:\xampp\htdocs\HUMAN VALUE\prueba\resources\views/pdf/imprimirlista.blade.php ENDPATH**/ ?>