

<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>LISTADO DE TELEFONOS</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<a href="telefonos/create" class="btn btn-success mb-4">CREAR</a>
<table id="telefonos" class="table table-light table-striped">
    <thead>
    <tr>
    <th>ID</th>
    <th>Persona</th>
    <th>Numero</th>
    <th>Tipo</th>
    <th>Acciones</th>
    </tr>
    </thead>
    <tbody>
    <?php $__currentLoopData = $telefonos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $telefono): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
    <td> <?php echo e($telefono->id); ?> </td>
    <td> <?php echo e($telefono->nombre); ?> </td>
    <td> <?php echo e($telefono->numero); ?> </td>
    <td> <?php echo e($telefono->descripcion); ?>  </td>
    <td>
    <form action="<?php echo e(route('telefonos.destroy', $telefono->id)); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <?php echo method_field('DELETE'); ?>
    <a href="/telefonos/<?php echo e($telefono->id); ?>/edit" class="btn btn-primary">Editar</a>
    <a href="/telefonos/<?php echo e($telefono->id); ?>" class="btn btn-info">Ver</a>
    <button type="submit" class="btn btn-danger">Eliminar</button>
    </form>
    </td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
    </table>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/admin_custom.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.22/css/dataTables.bootstrap5.min.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
    <script src="https://cdn.datatables.net/1.10.24/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.24/js/dataTables.bootstrap5.min.js"></script>

    <script>
    $(document).ready(function() {
        $('#telefonos').DataTable({
            "lengthMenu": [[5,10,50, -1], [5, 10, 50, "All"]]
        });
    });
    </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\HUMAN VALUE\prueba\resources\views/telefono/index.blade.php ENDPATH**/ ?>