

<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content_header'); ?>
<h1>EDITAR TELEFONO</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<form action="/telefonos" method="POST">
    <?php echo csrf_field(); ?>
    <div class="mb-3">
        <label class="form-label" for="numero">Numero:</label>
        <input value="<?php echo e($telefono->numero); ?>" required tabindex="0" class="form-control" id="numero" name="numero" type="number">
    </div>
    <div class="mb-3">
        <label class="form-label" for="tipo">Tipo:</label>
        <select class="form-control" name="tipo" id="tipo">
            <option value="<?php echo e($tipo->id); ?>" selected="selected"> <?php echo e($tipo->descripcion); ?> </option>
            <?php $__currentLoopData = $tipos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tip): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($tipo->id != $tip->id): ?>
            <option value="<?php echo e($tip->id); ?>"><?php echo e($tip->descripcion); ?></option>
            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>
    <div class="mb-3">
        <label class="form-label" for="persona">Persona:</label>
        <select class="form-control" name="persona" id="persona">
            <option value="<?php echo e($persona->id); ?>" selected="selected"> <?php echo e($persona->nombre); ?> </option>
            <?php $__currentLoopData = $personas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $person): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($persona->id != $person->id): ?>
            <option value="<?php echo e($person->id); ?>"><?php echo e($person->nombre); ?></option>
            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>
    <a href="/telefonos" tabindex="6" class="btn btn-danger">Back</a>
    <button type="submit" tabindex="5" class="btn btn-success">Save</button>
</form>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<link rel="stylesheet" href="/css/admin_custom.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script src="https://code.jquery.com/jquery-3.5.1.js"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\HUMAN VALUE\prueba\resources\views/telefono/edit.blade.php ENDPATH**/ ?>